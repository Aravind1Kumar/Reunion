3).
# Distinct types of project:
SELECT DISTINCT project_type
FROM Projects
WHERE date='2022-07-20';

#Average number of buildings per project:
SELECT AVG(num_buildings)
FROM (SELECT COUNT(*) as num_buildings
      FROM Buildings
      WHERE date='2022-07-20'
      GROUP BY RERA_ID) t;
      
      # All distinct types of unit configurations in the building:
      SELECT DISTINCT unit_type
FROM Buildings b JOIN Building_Unit_Configurations buc
  ON b.building_ID = buc.building_ID
WHERE date='2022-07-20';

# Maximum sanctioned FSI among all projects:
SELECT MAX(project_fsi.sanctioned_fsi)
FROM project_fsi
WHERE project_fsi.as_of_date = '2022-07-20';

#Average number of apartments per building throughout all the projects:
SELECT AVG(building_apartments.apartment_count)
FROM building_apartments;

4)
(Optional) What kind of EDA, cleanups and validations would you like to propose for the given data so that the quality of downstream analysis can be further improved upon:
Based on the given data, following are some EDA, cleanups, and validations that can be performed:

Check for missing or null values in the data and handle them appropriately.
Check for duplicates in the data and remove them.
Check for outliers in the data and handle them appropriately.
Standardize the data types across all the columns for consistency.
Check for data consistency across different dates for the same project.
Normalize the data by splitting nested columns into separate tables for better data organization and querying.
      